package com.IQVIAAssignment.IQVIARestAssured;

import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

class CapitalAPI
{
	String strCapitalName; //Variable to store the capital name retrieved
	String strCountryCurCode; //Variable to store all the Country Currency Code
    String strCapCurrenyCode; //String variable to store selected Capital Currency Code
	
	//Test to Invoke the Country API and to retrieve all the Country details
	@Test(priority=1)
	public void InvokeCountryAPI()
	{
		try
		{
			//Country API Test
			System.out.println("[1].Country API Test");
			System.out.println("=====================");
			
			//To specify the base URL to the RESTful web service
			RestAssured.baseURI = "http://restcountries.eu/rest/v2/all?fields=name;capital;currencies;latlngs";

			//To set the RequestSpecification of the request that needs to send to the server. The server is mentioned above in  the BaseURI
			RequestSpecification httpRequest = RestAssured.given();
            
			//To Make a request to the server by specifying the method Type and the method URL.This will return the Response from the server.
			Response response = httpRequest.request(Method.GET);

			//To get the status code or Rest Call.
			int statusCode=response.getStatusCode();
			//To get the CountryAPI Response
			String CountryAPIResponseBody = response.getBody().asString();
			
			System.out.println("[1].Country API Respone:="+CountryAPIResponseBody);
			
			//To get the JsonPath object instance from the Response interface
			 JsonPath jsonPathEvaluator = response.jsonPath();
			 
			 //To Retrieve the capital node values from the JsonPath
			String strCapital = jsonPathEvaluator.get("capital").toString();
						
			//To get the Capital Name
			String[] strCapitalTemp=strCapital.split(",");
			
			//To retrieve the the 1st,2nd,3rd,4th...nth capital names further,change the strCapitalTemp[0] to strCapitalTemp[1]/strCapitalTemp[2]/....strCapitalTemp[n].
			strCapitalName=strCapitalTemp[14].replace("[", "").replace("]","").trim();
					   
			//To Retrieve Currency Code
			strCountryCurCode=jsonPathEvaluator.get("currencies.code").toString();
			//To list display all the Country Currency Codes
			strCountryCurCode=strCountryCurCode.replace("[", "").replace("]", "").trim();
			//To display countries currency code in Console
			
		    System.out.println("The Countries Currency Code:="+strCountryCurCode);
			
			//To Validate the Status Code
			if(statusCode==200)
			{
				System.out.println("Test got Passed,Country API Status Code is:="+statusCode);
			}
			else
			{
				System.out.println("Test got failed,Capital API Status Code is:="+statusCode);
			}

		}
		catch(Exception e)
		{
			System.out.println("Exception:"+e);
		}
			System.out.println("");
 }
	
	//Test to Invoke the Capital_API with the Capital name extracted from the Country_API 
	@Test(priority=2)
	public void InvokeCapitalAPI()
	{
		try
		{
			//Capital API Test
			System.out.println("[2].Capital API Test");
			System.out.println("=====================");
			
			//To specify the base URL to the RESTful web service
			RestAssured.baseURI = "https://restcountries.eu/rest/v2/capital/"+strCapitalName+"?fields=name;capital;currencies;latlng;regionalBlocs";

			//To set the RequestSpecification of the request that needs to send to the server. The server is mentioned above in  the BaseURI
			RequestSpecification CapitalAPI_httpRequest = RestAssured.given();
            
			//To Make a request to the server by specifying the method Type and the method URL.This will return the Response from the server.
			Response CapitalAPIResponse = CapitalAPI_httpRequest.request(Method.GET);
			
			//To get the status code or Rest Call.
			int CapitalAPIstatusCode=CapitalAPIResponse.getStatusCode();
			String CapitalAPIresponseBody = CapitalAPIResponse.getBody().asString();
			
			//To get the JsonPath object instance from the Response interface
			 JsonPath jsonPathEvaluator = CapitalAPIResponse.jsonPath();
			
			System.out.println("Country API Response for the Capital Name "+strCapitalName+":="+CapitalAPIresponseBody);
			
			//To Retrieve Currency Code
			String strCapitalCurCode=jsonPathEvaluator.get("currencies.code").toString();
				
			strCapCurrenyCode=strCapitalCurCode.replace("[", "").replace("]", "").trim();
			
			System.out.println("Currency Code of the Capital API:Capital Name:="+strCapitalName+",Currency Code:="+strCapCurrenyCode);
				
				
			//To Validate the Status Code
			if(CapitalAPIstatusCode==200)
			{
				System.out.println("Test got Passed,Capital API Status Code is:="+CapitalAPIstatusCode);
			}
			else
			{
				System.out.println("Test got failed,Capital API Status Code is:="+CapitalAPIstatusCode);
			}
			
		}	
			catch(Exception e)
			{
				System.out.println("Exception:"+e);
			}

		
			System.out.println("");
}

	//Test to Validate whether the Capital API Currency code is matching with the Country API Currency Code
	@Test(priority=3)
	public void ValidateCurrencyCode() 
	{
		
		System.out.println("[3].Test to validate whether the currency code in the Capital API matches with the currency code in the Countries API");
		System.out.println("=======================================================================================================================");
		
		if(strCountryCurCode.contains(strCapCurrenyCode))
		{
			System.out.println("Capital API Currency Code Match with Country API Currency Code:"+strCapCurrenyCode);
		}
		else
		{
			System.out.println("Capital API Currency Code does not Match with Country API Currency Code:"+strCapCurrenyCode);
		}
			
		System.out.println("");
	}
	
	//Test to Validate Negative scenario
	@Test(priority=4)
	public void ValidateNegativeScenario()
	{
		try
		{
			//Negative Scenario Test
			System.out.println("[4].Negative Scenario Test");
			System.out.println("===========================");
			
			//To Make the Test deliberately fail, Passing the Capital name text as Test.
			strCapitalName="Test";
			
			//To specify the base URL to the RESTful web service
			RestAssured.baseURI = "https://restcountries.eu/rest/v2/capital/"+strCapitalName+"?fields=name;capital;currencies;latlng;regionalBlocs";

			//To set the RequestSpecification of the request that needs to send to the server. The server is mentioned above in  the BaseURI
			RequestSpecification CapitalAPI_httpRequest = RestAssured.given();
            
			//To Make a request to the server by specifying the method Type and the method URL.This will return the Response from the server.
			Response CapitalAPIResponse = CapitalAPI_httpRequest.request(Method.GET);
			
			//To get the status code or Rest Call.
			int CapitalAPIstatusCode=CapitalAPIResponse.getStatusCode();
			String CapitalAPIresponseBody = CapitalAPIResponse.getBody().asString();
			
			System.out.println("Country API Response for the Capital Name "+strCapitalName+":="+CapitalAPIresponseBody);
			
			//To Validate the Status Code
			if(CapitalAPIstatusCode==200)
			{
				System.out.println("Test got Passed,Capital API Status Code is:="+CapitalAPIstatusCode);
			}
			else
			{
				System.out.println("Test has been deliberately failed to cover negative scenario,Capital API Status Code is:="+CapitalAPIstatusCode);
			}
		}
			catch(Exception e)
			{
				System.out.println("Exception:"+e);
			}
			System.out.println("");				
	}
}	